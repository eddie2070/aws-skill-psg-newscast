module.exports = {
 consumer_key:         'CALbNRI6DQRsKfSnZ50QMmYNT',
  consumer_secret:      '0kH9K0gA6nFqhh7iBvrQk8fE0vl2Y1EL6xyD0xT5A3geNNF2ku',
  access_token:         '253757495-gCB1rrBotJNfTgLxZZvQT3RM4KcBPl0tHFdjNRZV',
  access_token_secret:  'vdnY5qG03bGLEsa5ENssM32h5qVJQjs56u6jFtZtlmVIw',
  tweet_mode: 'extended'
}